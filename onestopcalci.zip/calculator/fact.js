<script>
	function nfactorial(nfact){
	var ninp,nans,nval;
	
	nval = 1;
	nans = Number(document.getElementById("nfact").value);
	for(ninp = 1; ninp<=nans; ninp++)
	    {
	nval = nval*ninp;
		}
		document.getElementById("nanswer").value=nval;
	}
	
	function rfactorial(rfact){
	var rinp,rans,rval;
	
	rval = 1;
	rans = Number(document.getElementById("rfact").value);
	for(rinp = 1; rinp<=rans; rinp++)
	    {
	rval = rval*rinp;
		}
		document.getElementById("ranswer").value=rval;
	}
	
	function nmr(nmir){
	var nmri,nmrc,nmrb;
	nmrb=1;
	nmrc=Number(document.getElementById("nmra").value);
	for(nmri=1;nmri<=nmrc;nmri++){
	nmrb = nmrb*nmri;
	}
	document.getElementById("nmir").value=nmrb;
	}
	
	function perm(){
	num1 = document.getElementById('nfactv').value;
	num2 = document.getElementById('nmrv').value;
	document.getElementById('permutation').innerHTML=num1/num2;
	}
	
	function comb(){
	num3 = document.getElementById('nfactv').value;
	num4 = document.getElementById('nmrv').value;
	num5 = document.getElementById('rfactv').value;
	
	document.getElementById('combination').innerHTML=((num3)/((num4)*(num5)));
	}
	
	</script>